var config = {
    apiKey: "AIzaSyDW4sH0s-Jb9r7JMzG67AAW8VekNUFYsVA",
    authDomain: "respage-f9109.firebaseapp.com",
    databaseURL: "https://respage-f9109.firebaseio.com",
    projectId: "respage-f9109",
    storageBucket: "respage-f9109.appspot.com",
    messagingSenderId: "801377157386"
  };
  firebase.initializeApp(config);


var messagesRef= firebase.database().ref('messages');

document.getElementById('contactForm').addEventListener('submit',submitForm);

function submitForm(e){
e.preventDefault();

 var name = document.getElementById('name');
  var company = document.getElementById('company');
  var email = document.getElementById('email');
  var phone = document.getElementById('phone');
  var message = document.getElementById('message');

saveMessage(name,company,email,phone,message);


document.querySelector('alert').style.dispaly="block";

setTimeout(function(){
 document.querySelector('alert').style.display ="none";
},3000);

document.getElementById('contactForm').reset();
}


function saveMessage(name ,company,email,phone,message){
 var newMessageRef = messagesRef.push();
 newMessageRef.set({
   name: name,
   company: company,
   email: email,
   phone: phone,
   message: message
 });

   function hourglass(){
     let hourglass =
     document.getElementById('hourglass');
     hourglass.innerHTML="&#xf252;";
   }






}
