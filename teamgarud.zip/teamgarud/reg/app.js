const express= require('express');
const bodyParser = require('body-Parser');
const exphbs = require('express-handlebars');
const modemailer = require('nodemailer');
const path = require('path');

const app = express();
      
app.engine('handlebars',exphbs());
app.set('view engibe','handlebars');



app.use(bodyParser.urlencoded({extented: false}));
app.use(bodyParser.json());

app.use('/public', express.static(path.join(__dirname,'public')));




app.get('/',(req,res) =>{
  res.send('contact');
});


app.get('./send',(req,res) =>{
  const output=`
  <p> YOu have a new conatct request</p>
  <h3>Conatct Details</h3>
  <ul>
  <li>Name: ${req.body.name}</li>
  <li>Company: ${req.body.company}</li>
  <li>Email: ${req.body.email}</li>
  <li>Phone: ${req.body.phone}</li>
  </ul>
  
  `;
});

app.listen(3000, ()=>{
  console.log("server started att 3000");
});
